package com.example.uasperbaikan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
